# -*- coding: utf-8 -*-

__author__ = """Joabe Mendes"""
__email__ = 'joabe.mdl@gmail.com'
__version__ = '2.1.0'
