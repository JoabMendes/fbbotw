Facebook bot python wrapper
=======================

Python Wrapper for Facebook Messenger Bot Platform.

----
Perfect to use with Django

See documentation at: `Github <https://github.com/JoabMendes/fbbotw>`_.
