# -*- coding: utf-8 -*-

__author__ = """Joabe Mendes"""
__email__ = 'joabe@linux.com'
__version__ = '1.3.0'
